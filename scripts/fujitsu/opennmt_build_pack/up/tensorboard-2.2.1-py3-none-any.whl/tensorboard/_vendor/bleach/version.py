# -*- coding: utf-8 -*-

from __future__ import unicode_literals

VERSION = (2, 0, 0)
__version__ = '.'.join([str(n) for n in VERSION])
